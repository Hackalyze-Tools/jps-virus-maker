                                                                
                                                                
                   JPS Virus Maker (4.0)                        
                 Coded by Arash Veyskarami                      
                                                                
         You can create a nice virus && send to victim.         
      Before create virus you must change &&  set options.      
                Then Press Create Virus Button.                 
                                                                
                                                                

     Note : This application is designed for training only. 
     Like: CEH Courses.
     So please do not ask me how we can undetect it.


  We want to help the iranian flooded peoples.
  If you are also willing to help , you can send your helps

  By Bitcoin : 13TBHvYWHFR7efTLaeq8zFni4Y2ptZYJ9C

               Web: http://www.kernel32.ir
          Weblog : http://www.jeyjey.blogfa.com
                Email: Arashjeyjey Gmail.com
                       IRAN_LORESTAN
                        May/01/2019


New Features and some feature changed:

-Disable Yahoo
-Disable Norton Antivirus
-Disable Mcafee
-Disable MSN Messenger
-Disable Security Center
-Terminate Windows
-Destroy Offlines(Y!Messenger)
-Destroy Protected Storage
-Destory Audio Service
-Clear Windows XP
-Hide Tasks in TaskManager
-Hide Outlook Express

 Lock Screen
 Remove Bluetooth
 Remove Windows Themes
 Slow Mouse Speed
 Disable Drives
 Disable Windows Update
 Disable Browsers
 Disable Telegram
 Turn Off Windows Defender
 Turn Off Windows Firewall
 Run in system mode
 Convert to Backdoor
 Convert to Logical Bomb
 changed server icons
 Multi platform supported. you can make 32bit or 64bit viruses.

*Some bugs fixed.


